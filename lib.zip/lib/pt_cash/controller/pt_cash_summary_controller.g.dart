// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pt_cash_summary_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$ptCashSummaryHash() => r'0b661561c7371f90bf3e07c89b1bcb1e97b89d85';

/// See also [ptCashSummary].
@ProviderFor(ptCashSummary)
final ptCashSummaryProvider =
    AutoDisposeFutureProvider<PtSummaryModel>.internal(
  ptCashSummary,
  name: r'ptCashSummaryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$ptCashSummaryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef PtCashSummaryRef = AutoDisposeFutureProviderRef<PtSummaryModel>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
