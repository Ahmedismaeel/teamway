// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pt_cash_all_summary_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$allPtCashSummaryHash() => r'3604c0b156fc510aa7c5d7d1b5844b235978c85a';

/// See also [allPtCashSummary].
@ProviderFor(allPtCashSummary)
final allPtCashSummaryProvider =
    AutoDisposeFutureProvider<List<PtSummaryModel>>.internal(
  allPtCashSummary,
  name: r'allPtCashSummaryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$allPtCashSummaryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AllPtCashSummaryRef
    = AutoDisposeFutureProviderRef<List<PtSummaryModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
