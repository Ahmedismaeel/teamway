// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'my_profile_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getMyProfileHash() => r'a1ca31993650121e0e74641c59b749a4956ad6a8';

/// See also [getMyProfile].
@ProviderFor(getMyProfile)
final getMyProfileProvider = FutureProvider<ProfileModel>.internal(
  getMyProfile,
  name: r'getMyProfileProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$getMyProfileHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GetMyProfileRef = FutureProviderRef<ProfileModel>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
