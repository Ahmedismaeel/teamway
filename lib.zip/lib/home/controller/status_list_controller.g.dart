// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'status_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$statusListHash() => r'49e346dd968ea415050d10656a24c5b16f9e3cfe';

/// See also [statusList].
@ProviderFor(statusList)
final statusListProvider = AutoDisposeFutureProvider<void>.internal(
  statusList,
  name: r'statusListProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$statusListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef StatusListRef = AutoDisposeFutureProviderRef<void>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
