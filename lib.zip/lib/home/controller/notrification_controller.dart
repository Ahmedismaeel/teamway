// import 'package:internal_app/global/end_points.dart';
// import 'package:internal_app/global/helper/api_helper.dart';
// import 'package:internal_app/home/model/notification_list_model.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';

// part 'notrification_controller.g.dart';

// @riverpod
// Future<NotificationListModel> myNotification(MyNotificationRef ref) async {
//   return await EndPoints.myNotification(page: ,pageSize: )
//       .get(fromJson: NotificationListModel.fromJson);
// }
