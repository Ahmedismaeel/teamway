// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'team_member_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getTeamMemberHash() => r'7e65776395d3f9fce06083bc7977e2ffe4272632';

/// See also [getTeamMember].
@ProviderFor(getTeamMember)
final getTeamMemberProvider =
    AutoDisposeFutureProvider<List<MemberModel>>.internal(
  getTeamMember,
  name: r'getTeamMemberProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getTeamMemberHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GetTeamMemberRef = AutoDisposeFutureProviderRef<List<MemberModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
