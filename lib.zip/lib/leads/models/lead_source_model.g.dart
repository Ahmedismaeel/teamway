// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lead_source_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_LeadSourceModel _$$_LeadSourceModelFromJson(Map<String, dynamic> json) =>
    _$_LeadSourceModel(
      id: json['id'] as int?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$$_LeadSourceModelToJson(_$_LeadSourceModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
    };
