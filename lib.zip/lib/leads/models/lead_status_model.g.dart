// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lead_status_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_LeadStatusModel _$$_LeadStatusModelFromJson(Map<String, dynamic> json) =>
    _$_LeadStatusModel(
      id: json['id'] as int?,
      title: json['title'] as String?,
      color: json['color'] as String?,
    );

Map<String, dynamic> _$$_LeadStatusModelToJson(_$_LeadStatusModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
      'color': instance.color,
    };
