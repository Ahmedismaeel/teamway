// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_lead_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addLeadHash() => r'9be7fbdbfe74764466e533c84fbbb5f22b34471a';

/// See also [AddLead].
@ProviderFor(AddLead)
final addLeadProvider =
    AutoDisposeNotifierProvider<AddLead, SubmitState<int>>.internal(
  AddLead.new,
  name: r'addLeadProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$addLeadHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddLead = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
