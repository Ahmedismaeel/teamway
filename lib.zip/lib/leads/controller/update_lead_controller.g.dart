// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_lead_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$updateLeadHash() => r'1ce6f5a14fae6a65eabd1b6b0171d49b291d2626';

/// See also [UpdateLead].
@ProviderFor(UpdateLead)
final updateLeadProvider =
    AutoDisposeNotifierProvider<UpdateLead, SubmitState<int>>.internal(
  UpdateLead.new,
  name: r'updateLeadProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$updateLeadHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UpdateLead = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
