// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_comment_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addCommentLeadHash() => r'cdcc1da73788e46d69652e23ba7cc14d4fb376ca';

/// See also [AddCommentLead].
@ProviderFor(AddCommentLead)
final addCommentLeadProvider =
    AutoDisposeNotifierProvider<AddCommentLead, SubmitState<int>>.internal(
  AddCommentLead.new,
  name: r'addCommentLeadProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addCommentLeadHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddCommentLead = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
