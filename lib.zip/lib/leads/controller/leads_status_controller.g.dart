// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'leads_status_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$leadStatusListHash() => r'df9456d59a72856271bb3fa3a6a7f1e65a8d35d8';

/// See also [leadStatusList].
@ProviderFor(leadStatusList)
final leadStatusListProvider =
    AutoDisposeFutureProvider<List<LeadStatusModel>>.internal(
  leadStatusList,
  name: r'leadStatusListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$leadStatusListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef LeadStatusListRef = AutoDisposeFutureProviderRef<List<LeadStatusModel>>;
String _$leadSourceListHash() => r'8e55b13e1f0a1f78fdf21064ac8262c912d454e8';

/// See also [leadSourceList].
@ProviderFor(leadSourceList)
final leadSourceListProvider =
    AutoDisposeFutureProvider<List<LeadSourceModel>>.internal(
  leadSourceList,
  name: r'leadSourceListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$leadSourceListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef LeadSourceListRef = AutoDisposeFutureProviderRef<List<LeadSourceModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
