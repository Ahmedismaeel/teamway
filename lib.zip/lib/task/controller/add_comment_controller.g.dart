// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_comment_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addCommentControllerHash() =>
    r'b50826c253f93180a866063e648f70faf50cbdaa';

/// See also [AddCommentController].
@ProviderFor(AddCommentController)
final addCommentControllerProvider = AutoDisposeNotifierProvider<
    AddCommentController, SubmitState<int>>.internal(
  AddCommentController.new,
  name: r'addCommentControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addCommentControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddCommentController = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
