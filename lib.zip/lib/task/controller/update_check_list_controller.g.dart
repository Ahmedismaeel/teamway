// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_check_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$updateCheckListHash() => r'71bdfd5f031fb7b69195dfb6988f3c4a0cf13c5b';

/// See also [UpdateCheckList].
@ProviderFor(UpdateCheckList)
final updateCheckListProvider =
    AutoDisposeNotifierProvider<UpdateCheckList, SubmitState<int>>.internal(
  UpdateCheckList.new,
  name: r'updateCheckListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$updateCheckListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UpdateCheckList = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
