// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_task_status_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$updateTaskStatusHash() => r'd3a0930b0aec7f851088b0c7584ec943165e62a9';

/// See also [UpdateTaskStatus].
@ProviderFor(UpdateTaskStatus)
final updateTaskStatusProvider =
    AutoDisposeNotifierProvider<UpdateTaskStatus, SubmitState<int>>.internal(
  UpdateTaskStatus.new,
  name: r'updateTaskStatusProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$updateTaskStatusHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UpdateTaskStatus = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
