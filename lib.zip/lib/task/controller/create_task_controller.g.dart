// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_task_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$createTaskHash() => r'0e3284173179572f4b8449d1f79cb5b66e98bacb';

/// See also [CreateTask].
@ProviderFor(CreateTask)
final createTaskProvider =
    AutoDisposeNotifierProvider<CreateTask, SubmitState<int>>.internal(
  CreateTask.new,
  name: r'createTaskProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$createTaskHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CreateTask = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
