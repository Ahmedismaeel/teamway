// class CheckListModel {
//   String? id;
//   String? title;
//   String? isChecked;
//   String? sort;

//   CheckListModel({this.id, this.title, this.isChecked, this.sort});

//   CheckListModel.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     title = json['title'];
//     isChecked = json['is_checked'];
//     sort = json['sort'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['title'] = this.title;
//     data['is_checked'] = this.isChecked;
//     data['sort'] = this.sort;
//     return data;
//   }
// }
