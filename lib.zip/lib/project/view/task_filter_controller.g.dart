// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'task_filter_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$statusFilterHash() => r'44bc84873522fe1b909773397ae01e8368ff1bff';

/// See also [StatusFilter].
@ProviderFor(StatusFilter)
final statusFilterProvider =
    AutoDisposeNotifierProvider<StatusFilter, List<StatusModel>>.internal(
  StatusFilter.new,
  name: r'statusFilterProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$statusFilterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$StatusFilter = AutoDisposeNotifier<List<StatusModel>>;
String _$memberFilterHash() => r'415a12e9f35a9a85a9cd791120f7bc1ab5777dbc';

/// See also [MemberFilter].
@ProviderFor(MemberFilter)
final memberFilterProvider =
    AutoDisposeNotifierProvider<MemberFilter, List<MemberModel>>.internal(
  MemberFilter.new,
  name: r'memberFilterProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$memberFilterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MemberFilter = AutoDisposeNotifier<List<MemberModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
