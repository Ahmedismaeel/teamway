// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_file_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addProjectsFileHash() => r'25bfb686febdbd314c32a54ec975007a13eb4fac';

/// See also [AddProjectsFile].
@ProviderFor(AddProjectsFile)
final addProjectsFileProvider =
    AutoDisposeNotifierProvider<AddProjectsFile, SubmitState<int>>.internal(
  AddProjectsFile.new,
  name: r'addProjectsFileProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addProjectsFileHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddProjectsFile = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
