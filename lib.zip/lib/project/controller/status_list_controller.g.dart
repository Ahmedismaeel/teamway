// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'status_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$projectStatusListHash() => r'200698c8b7f47a09d756f09dc7e0b1c846cb1aa6';

/// See also [projectStatusList].
@ProviderFor(projectStatusList)
final projectStatusListProvider =
    AutoDisposeFutureProvider<List<String>>.internal(
  projectStatusList,
  name: r'projectStatusListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$projectStatusListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef ProjectStatusListRef = AutoDisposeFutureProviderRef<List<String>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
