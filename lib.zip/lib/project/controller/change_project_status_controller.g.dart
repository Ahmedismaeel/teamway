// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'change_project_status_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$updateProjectStatusHash() =>
    r'2f5a58131cd02a92829771b3ee744aea28ce5769';

/// See also [UpdateProjectStatus].
@ProviderFor(UpdateProjectStatus)
final updateProjectStatusProvider =
    AutoDisposeNotifierProvider<UpdateProjectStatus, SubmitState<int>>.internal(
  UpdateProjectStatus.new,
  name: r'updateProjectStatusProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$updateProjectStatusHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UpdateProjectStatus = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
