// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_project_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getProjectListHash() => r'ad28d22277f29431f8e289734ec90214977d34a5';

/// See also [getProjectList].
@ProviderFor(getProjectList)
final getProjectListProvider =
    AutoDisposeFutureProvider<List<ProjectModel>>.internal(
  getProjectList,
  name: r'getProjectListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getProjectListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GetProjectListRef = AutoDisposeFutureProviderRef<List<ProjectModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
