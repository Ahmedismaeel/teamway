// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'site_status_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$siteStatusListHash() => r'c94da2b61d6db3335c630fee56beac1b40285774';

/// See also [siteStatusList].
@ProviderFor(siteStatusList)
final siteStatusListProvider =
    AutoDisposeFutureProvider<List<SiteStatusModel>>.internal(
  siteStatusList,
  name: r'siteStatusListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$siteStatusListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef SiteStatusListRef = AutoDisposeFutureProviderRef<List<SiteStatusModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
