// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_comment_project_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addCommentProjectHash() => r'b9053cc18d278907bf081c5468fcee7ecedfaccd';

/// See also [AddCommentProject].
@ProviderFor(AddCommentProject)
final addCommentProjectProvider =
    AutoDisposeNotifierProvider<AddCommentProject, SubmitState<int>>.internal(
  AddCommentProject.new,
  name: r'addCommentProjectProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addCommentProjectHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddCommentProject = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
