// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'site_stage_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$siteStageListHash() => r'ca0cf48c1d1a3a1e65378092c70bbcef74ba81db';

/// See also [siteStageList].
@ProviderFor(siteStageList)
final siteStageListProvider =
    AutoDisposeFutureProvider<List<SiteStageModel>>.internal(
  siteStageList,
  name: r'siteStageListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$siteStageListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef SiteStageListRef = AutoDisposeFutureProviderRef<List<SiteStageModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
