// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project_system_type_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$systemProjectListHash() => r'b66fba7a7b49f8c43bfc7459439347231d2600a3';

/// See also [systemProjectList].
@ProviderFor(systemProjectList)
final systemProjectListProvider =
    AutoDisposeFutureProvider<List<SiteStatusModel>>.internal(
  systemProjectList,
  name: r'systemProjectListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$systemProjectListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef SystemProjectListRef
    = AutoDisposeFutureProviderRef<List<SiteStatusModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
