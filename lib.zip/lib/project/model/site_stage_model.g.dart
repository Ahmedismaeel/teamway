// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'site_stage_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_SiteStageModel _$$_SiteStageModelFromJson(Map<String, dynamic> json) =>
    _$_SiteStageModel(
      id: json['id'] as int?,
      site_status_id: json['site_status_id'] as String?,
      title: json['title'] as String?,
      color: json['color'] as String?,
    );

Map<String, dynamic> _$$_SiteStageModelToJson(_$_SiteStageModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'site_status_id': instance.site_status_id,
      'title': instance.title,
      'color': instance.color,
    };
