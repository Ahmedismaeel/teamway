// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'duo_amount_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_DuoAmountModel _$$_DuoAmountModelFromJson(Map<String, dynamic> json) =>
    _$_DuoAmountModel(
      success: json['success'] as bool?,
      due: json['due'] as String?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$_DuoAmountModelToJson(_$_DuoAmountModel instance) =>
    <String, dynamic>{
      'success': instance.success,
      'due': instance.due,
      'message': instance.message,
    };
