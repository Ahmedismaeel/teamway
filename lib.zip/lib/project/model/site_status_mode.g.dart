// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'site_status_mode.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_SiteStatusModel _$$_SiteStatusModelFromJson(Map<String, dynamic> json) =>
    _$_SiteStatusModel(
      id: json['id'] as int?,
      title: json['title'] as String?,
      color: json['color'] as String?,
    );

Map<String, dynamic> _$$_SiteStatusModelToJson(_$_SiteStatusModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
      'color': instance.color,
    };
