// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_operation_model_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UpdateOperationRequestModel _$$_UpdateOperationRequestModelFromJson(
        Map<String, dynamic> json) =>
    _$_UpdateOperationRequestModel(
      name: json['name'] as String?,
      value: json['value'] as int?,
    );

Map<String, dynamic> _$$_UpdateOperationRequestModelToJson(
        _$_UpdateOperationRequestModel instance) =>
    <String, dynamic>{
      'name': instance.name,
      'value': instance.value,
    };
