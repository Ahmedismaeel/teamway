// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dropdown_string.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_DropDownStringModel _$$_DropDownStringModelFromJson(
        Map<String, dynamic> json) =>
    _$_DropDownStringModel(
      id: json['id'] as String?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$$_DropDownStringModelToJson(
        _$_DropDownStringModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
    };
