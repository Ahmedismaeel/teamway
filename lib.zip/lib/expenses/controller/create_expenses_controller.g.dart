// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_expenses_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$createExpensesHash() => r'68697536bbb692269e469c4fff52bfc27d0849e1';

/// See also [CreateExpenses].
@ProviderFor(CreateExpenses)
final createExpensesProvider =
    AutoDisposeNotifierProvider<CreateExpenses, SubmitState<int>>.internal(
  CreateExpenses.new,
  name: r'createExpensesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$createExpensesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CreateExpenses = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
