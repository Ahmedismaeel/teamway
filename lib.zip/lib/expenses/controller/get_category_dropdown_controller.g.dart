// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_category_dropdown_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getExpensesCategoryListHash() =>
    r'7b2e81bfaf85d01103423f040821d8bc643e576b';

/// See also [getExpensesCategoryList].
@ProviderFor(getExpensesCategoryList)
final getExpensesCategoryListProvider =
    AutoDisposeFutureProvider<List<DropdownModel>>.internal(
  getExpensesCategoryList,
  name: r'getExpensesCategoryListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getExpensesCategoryListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GetExpensesCategoryListRef
    = AutoDisposeFutureProviderRef<List<DropdownModel>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
