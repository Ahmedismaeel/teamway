// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fcm_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$fCMControllerHash() => r'ba9fb488976ed04103fcd2ab1191abf7b48166ce';

/// See also [FCMController].
@ProviderFor(FCMController)
final fCMControllerProvider =
    AutoDisposeNotifierProvider<FCMController, SubmitState<int>>.internal(
  FCMController.new,
  name: r'fCMControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$fCMControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FCMController = AutoDisposeNotifier<SubmitState<int>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
