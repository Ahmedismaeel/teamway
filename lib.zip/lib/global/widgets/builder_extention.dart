import 'package:flutter/material.dart';
import 'package:internal_app/global/helper/dialog_widget.dart';

extension AddBuilder on Widget {
  withBuilder({required Function(BuildContext) onTap}) {
    return Builder(
      builder: (BuildContext context) {
        return InkWell(
            onTap: () {
              onTap(context);
            },
            child: this);
      },
    );
  }
}
